const express = require("express")
const http = require("http")
const cors = require("cors")
const { Server } = require("socket.io")
const admin = require("firebase-admin")
const { spawn } = require("child_process")
const dotenv = require("dotenv")

// Load environment variables
dotenv.config()

// Initialize Firebase Admin
const serviceAccount = require("./serviceAccountKey.json")
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
})

const db = admin.firestore()
const bucket = admin.storage().bucket()

// Initialize Express
const app = express()
const server = http.createServer(app)

// Middleware
app.use(cors())
app.use(express.json())

// Initialize Socket.io
const io = new Server(server, {
  cors: {
    origin: process.env.CLIENT_URL || "http://localhost:5173",
    methods: ["GET", "POST"],
  },
})

// Socket.io connection handler
io.on("connection", (socket) => {
  console.log("User connected:", socket.id)

  // Join a private chat room
  socket.on("join_private_chat", (chatId) => {
    socket.join(`private_${chatId}`)
    console.log(`User ${socket.id} joined private chat: ${chatId}`)
  })

  // Join a public chat room
  socket.on("join_public_chat", (roomId) => {
    socket.join(`public_${roomId}`)
    console.log(`User ${socket.id} joined public chat: ${roomId}`)
  })

  // Handle private message
  socket.on("private_message", async (data) => {
    try {
      // Store message in Firestore
      await db.collection("private_messages").add({
        chatId: data.chatId,
        senderId: data.senderId,
        receiverId: data.receiverId,
        content: data.content,
        timestamp: admin.firestore.FieldValue.serverTimestamp(),
        read: false,
      })

      // Emit message to the private chat room
      io.to(`private_${data.chatId}`).emit("receive_message", {
        ...data,
        timestamp: new Date().toISOString(),
      })
    } catch (error) {
      console.error("Error sending private message:", error)
    }
  })

  // Handle public message
  socket.on("public_message", async (data) => {
    try {
      // Check content with NLP before storing
      const isInappropriate = await checkContentWithNLP(data.content)

      if (isInappropriate) {
        // Notify sender that message was flagged
        socket.emit("message_flagged", {
          message: "Your message contains inappropriate content and was not sent.",
        })
        return
      }

      // Store message in Firestore
      await db.collection("public_messages").add({
        roomId: data.roomId,
        senderId: data.senderId,
        senderName: data.senderName,
        content: data.content,
        timestamp: admin.firestore.FieldValue.serverTimestamp(),
      })

      // Emit message to the public chat room
      io.to(`public_${data.roomId}`).emit("receive_message", {
        ...data,
        timestamp: new Date().toISOString(),
      })
    } catch (error) {
      console.error("Error sending public message:", error)
    }
  })

  // Handle typing indicator
  socket.on("typing", (data) => {
    if (data.chatType === "private") {
      socket.to(`private_${data.chatId}`).emit("user_typing", {
        userId: data.userId,
        isTyping: data.isTyping,
      })
    } else {
      socket.to(`public_${data.roomId}`).emit("user_typing", {
        userId: data.userId,
        userName: data.userName,
        isTyping: data.isTyping,
      })
    }
  })

  // Handle disconnect
  socket.on("disconnect", () => {
    console.log("User disconnected:", socket.id)
  })
})

// Function to check content with spaCy NLP
async function checkContentWithNLP(content) {
  return new Promise((resolve) => {
    const pythonProcess = spawn("python", ["nlp_processor.py", content])

    let result = ""
    pythonProcess.stdout.on("data", (data) => {
      result += data.toString()
    })

    pythonProcess.on("close", (code) => {
      if (code !== 0) {
        console.error("NLP process exited with code", code)
        resolve(false) // Default to allowing content if NLP fails
      } else {
        resolve(result.trim() === "inappropriate")
      }
    })
  })
}

// API Routes
app.get("/api/health", (req, res) => {
  res.status(200).json({ status: "ok" })
})

// User routes
app.get("/api/users/:userId", async (req, res) => {
  try {
    const userId = req.params.userId
    const userDoc = await db.collection("users").doc(userId).get()

    if (!userDoc.exists) {
      return res.status(404).json({ error: "User not found" })
    }

    const userData = userDoc.data()
    // Remove sensitive information
    delete userData.email

    res.status(200).json(userData)
  } catch (error) {
    console.error("Error fetching user:", error)
    res.status(500).json({ error: "Server error" })
  }
})

// Post routes
app.get("/api/posts", async (req, res) => {
  try {
    const postsSnapshot = await db.collection("posts").orderBy("createdAt", "desc").limit(20).get()

    const posts = []
    postsSnapshot.forEach((doc) => {
      posts.push({
        id: doc.id,
        ...doc.data(),
      })
    })

    res.status(200).json(posts)
  } catch (error) {
    console.error("Error fetching posts:", error)
    res.status(500).json({ error: "Server error" })
  }
})

app.post("/api/posts", async (req, res) => {
  try {
    const { content, authorId, authorName } = req.body

    if (!content || !authorId) {
      return res.status(400).json({ error: "Missing required fields" })
    }

    // Check content with NLP
    const isInappropriate = await checkContentWithNLP(content)

    if (isInappropriate) {
      return res.status(400).json({ error: "Post contains inappropriate content" })
    }

    const newPost = {
      content,
      authorId,
      authorName: authorName || "Anonymous",
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      likes: [],
      dislikes: [],
      reports: [],
      comments: [],
      flagStatus: "blank",
    }

    const docRef = await db.collection("posts").add(newPost)

    res.status(201).json({
      id: docRef.id,
      ...newPost,
      createdAt: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Error creating post:", error)
    res.status(500).json({ error: "Server error" })
  }
})

// Start server
const PORT = process.env.PORT || 5000
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})
