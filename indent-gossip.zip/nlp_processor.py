import sys
import spacy
import re

# Load spaCy model
try:
    nlp = spacy.load("en_core_web_sm")
except:
    # If model not found, download it
    import subprocess
    subprocess.run([sys.executable, "-m", "spacy", "download", "en_core_web_sm"])
    nlp = spacy.load("en_core_web_sm")

# Define inappropriate words and patterns
INAPPROPRIATE_WORDS = [
    "badword1", "badword2", "offensive", "slur", "explicit"
    # Add more inappropriate words here
]

def check_content(text):
    # Convert to lowercase for case-insensitive matching
    text_lower = text.lower()
    
    # Check for inappropriate words
    for word in INAPPROPRIATE_WORDS:
        if re.search(r'\b' + re.escape(word) + r'\b', text_lower):
            return True
    
    # Process with spaCy
    doc = nlp(text)
    
    # Check for negative sentiment (simplified)
    # In a real app, you would use a more sophisticated sentiment analysis
    negative_count = 0
    for token in doc:
        if token.is_stop or token.is_punct:
            continue
        if token.text.lower() in ["hate", "kill", "hurt", "bad", "terrible", "awful"]:
            negative_count += 1
    
    # If more than 20% of non-stop words are negative, flag as inappropriate
    non_stop_words = [token for token in doc if not token.is_stop and not token.is_punct]
    if non_stop_words and negative_count / len(non_stop_words) > 0.2:
        return True
    
    return False

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python nlp_processor.py 'text to analyze'")
        sys.exit(1)
    
    content = sys.argv[1]
    result = check_content(content)
    
    if result:
        print("inappropriate")
    else:
        print("appropriate")
