"use client"

import { useState, useEffect } from "react"
import { useParams } from "react-router-dom"
import { useAuth } from "../contexts/AuthContext"
import "./ProfilePage.css"

function ProfilePage() {
  const { userId } = useParams()
  const { currentUser } = useAuth()
  const [profile, setProfile] = useState(null)
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState({
    profileViews: 0,
    postImpressions: 0,
    posts: [],
  })

  useEffect(() => {
    // In a real app, fetch the user profile from Firestore
    // For now, we'll use mock data
    setTimeout(() => {
      setProfile({
        username: "Anonymous User",
        joinDate: "May 2023",
        bio: "This is a sample profile for the Indent Gossip platform.",
      })

      setStats({
        profileViews: 124,
        postImpressions: 1543,
        posts: [
          {
            id: 1,
            content: "This is a sample post from this user.",
            likes: 15,
            dislikes: 3,
            flagStatus: "green",
          },
          {
            id: 2,
            content: "Another sample post from this user.",
            likes: 8,
            dislikes: 2,
            flagStatus: "blank",
          },
        ],
      })

      setLoading(false)
    }, 1000)
  }, [userId])

  if (loading) {
    return <div className="loading">Loading profile...</div>
  }

  return (
    <div className="profile-page">
      <div className="profile-header">
        <div className="profile-avatar">
          {/* Display first letter of username */}
          {profile.username.charAt(0).toUpperCase()}
        </div>
        <div className="profile-info">
          <h2>{profile.username}</h2>
          <p className="join-date">Joined {profile.joinDate}</p>
        </div>
      </div>

      <div className="profile-bio">
        <h3>Bio</h3>
        <p>{profile.bio}</p>
      </div>

      <div className="profile-stats">
        <div className="stat-item">
          <span className="stat-value">{stats.profileViews}</span>
          <span className="stat-label">Profile Views</span>
        </div>
        <div className="stat-item">
          <span className="stat-value">{stats.postImpressions}</span>
          <span className="stat-label">Post Impressions</span>
        </div>
        <div className="stat-item">
          <span className="stat-value">{stats.posts.length}</span>
          <span className="stat-label">Posts</span>
        </div>
      </div>

      <div className="profile-posts">
        <h3>Posts</h3>
        {stats.posts.map((post) => (
          <div key={post.id} className="post">
            <div className="post-content">{post.content}</div>
            <div className="post-footer">
              <span className={`flag ${post.flagStatus}`}></span>
              <div className="post-stats">
                <span>{post.likes} likes</span>
                <span>{post.dislikes} dislikes</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default ProfilePage
