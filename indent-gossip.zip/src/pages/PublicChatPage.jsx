"use client"

import { useState, useEffect, useRef } from "react"
import { useAuth } from "../contexts/AuthContext"
import { FaPaperPlane, FaImage, FaUsers } from "react-icons/fa"
import "./ChatPages.css"

function PublicChatPage() {
  const { currentUser } = useAuth()
  const [messages, setMessages] = useState([])
  const [newMessage, setNewMessage] = useState("")
  const [activeUsers, setActiveUsers] = useState(12) // Mock number of active users
  const [roomName, setRoomName] = useState("General Chat")
  const messagesEndRef = useRef(null)

  // Scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    // In a real app, fetch messages from Firestore and listen for new ones with Socket.io
    // For now, we'll use mock data
    setMessages([
      {
        id: 1,
        senderId: "user123",
        senderName: "Anonymous1",
        content: "Welcome to the public chat room!",
        timestamp: new Date(Date.now() - 3600000).toISOString(),
      },
      {
        id: 2,
        senderId: "user456",
        senderName: "Anonymous2",
        content: "Hey everyone! How's it going?",
        timestamp: new Date(Date.now() - 3000000).toISOString(),
      },
      {
        id: 3,
        senderId: currentUser?.uid || "currentUser",
        senderName: "You",
        content: "I'm new here. This platform looks interesting!",
        timestamp: new Date(Date.now() - 2400000).toISOString(),
      },
      {
        id: 4,
        senderId: "user789",
        senderName: "Anonymous3",
        content: "Welcome to Indent Gossip! Feel free to share your thoughts anonymously.",
        timestamp: new Date(Date.now() - 1800000).toISOString(),
      },
    ])

    // Simulate active users changing
    const usersInterval = setInterval(() => {
      setActiveUsers((prev) => Math.max(5, prev + Math.floor(Math.random() * 3) - 1))
    }, 10000)

    return () => clearInterval(usersInterval)
  }, [currentUser])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = (e) => {
    e.preventDefault()

    if (!newMessage.trim()) return

    // In a real app, send message to backend/Socket.io
    const newMsg = {
      id: Date.now(),
      senderId: currentUser?.uid || "currentUser",
      senderName: "You",
      content: newMessage,
      timestamp: new Date().toISOString(),
    }

    setMessages((prev) => [...prev, newMsg])
    setNewMessage("")
  }

  const formatTime = (timestamp) => {
    const date = new Date(timestamp)
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  return (
    <div className="chat-page public-chat">
      <div className="chat-header">
        <div className="room-info">
          <h3>{roomName}</h3>
          <div className="active-users">
            <FaUsers /> <span>{activeUsers} active users</span>
          </div>
        </div>
      </div>

      <div className="messages-container">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`message ${message.senderId === (currentUser?.uid || "currentUser") ? "sent" : "received"}`}
          >
            {message.senderId !== (currentUser?.uid || "currentUser") && (
              <div className="message-sender">{message.senderName}</div>
            )}
            <div className="message-content">{message.content}</div>
            <div className="message-time">{formatTime(message.timestamp)}</div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      <form className="message-form" onSubmit={handleSendMessage}>
        <button type="button" className="attach-button">
          <FaImage />
        </button>
        <input
          type="text"
          placeholder="Type a message..."
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
        />
        <button type="submit" className="send-button">
          <FaPaperPlane />
        </button>
      </form>
    </div>
  )
}

export default PublicChatPage
