"use client"

import { useState, useEffect } from "react"
import { Link } from "react-router-dom"
import { useAuth } from "../contexts/AuthContext"
import { FaFire, FaUserCircle } from "react-icons/fa"
import "./TapsPage.css"

function TapsPage() {
  const { currentUser } = useAuth()
  const [tapsReceived, setTapsReceived] = useState([])
  const [tapsSent, setTapsSent] = useState([])
  const [activeTab, setActiveTab] = useState("received")

  useEffect(() => {
    // In a real app, fetch taps from Firestore
    // For now, we'll use mock data
    setTapsReceived([
      {
        id: 1,
        userId: "user123",
        username: "Anonymous1",
        timestamp: new Date(Date.now() - 3600000).toISOString(),
      },
      {
        id: 2,
        userId: "user456",
        username: "Anonymous2",
        timestamp: new Date(Date.now() - 7200000).toISOString(),
      },
      {
        id: 3,
        userId: "user789",
        username: "Anonymous3",
        timestamp: new Date(Date.now() - 86400000).toISOString(),
      },
    ])

    setTapsSent([
      {
        id: 1,
        userId: "user321",
        username: "Anonymous4",
        timestamp: new Date(Date.now() - 4800000).toISOString(),
      },
      {
        id: 2,
        userId: "user654",
        username: "Anonymous5",
        timestamp: new Date(Date.now() - 9600000).toISOString(),
      },
    ])
  }, [])

  const formatTime = (timestamp) => {
    const date = new Date(timestamp)
    const now = new Date()
    const diffMs = now - date
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24))
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60))
    const diffMinutes = Math.floor(diffMs / (1000 * 60))

    if (diffDays > 0) {
      return `${diffDays} day${diffDays > 1 ? "s" : ""} ago`
    } else if (diffHours > 0) {
      return `${diffHours} hour${diffHours > 1 ? "s" : ""} ago`
    } else {
      return `${diffMinutes} minute${diffMinutes > 1 ? "s" : ""} ago`
    }
  }

  return (
    <div className="taps-page">
      <h1>Taps</h1>
      <p className="subtitle">See who's interested in you</p>

      <div className="tabs">
        <button className={`tab ${activeTab === "received" ? "active" : ""}`} onClick={() => setActiveTab("received")}>
          Received ({tapsReceived.length})
        </button>
        <button className={`tab ${activeTab === "sent" ? "active" : ""}`} onClick={() => setActiveTab("sent")}>
          Sent ({tapsSent.length})
        </button>
      </div>

      <div className="taps-list">
        {activeTab === "received" ? (
          tapsReceived.length > 0 ? (
            tapsReceived.map((tap) => (
              <div key={tap.id} className="tap-item">
                <div className="tap-user">
                  <div className="tap-avatar">
                    <FaUserCircle />
                  </div>
                  <div className="tap-info">
                    <Link to={`/profile/${tap.userId}`} className="tap-username">
                      {tap.username}
                    </Link>
                    <span className="tap-time">{formatTime(tap.timestamp)}</span>
                  </div>
                </div>
                <div className="tap-icon">
                  <FaFire />
                </div>
              </div>
            ))
          ) : (
            <div className="no-taps">
              <p>You haven't received any taps yet.</p>
            </div>
          )
        ) : tapsSent.length > 0 ? (
          tapsSent.map((tap) => (
            <div key={tap.id} className="tap-item">
              <div className="tap-user">
                <div className="tap-avatar">
                  <FaUserCircle />
                </div>
                <div className="tap-info">
                  <Link to={`/profile/${tap.userId}`} className="tap-username">
                    {tap.username}
                  </Link>
                  <span className="tap-time">{formatTime(tap.timestamp)}</span>
                </div>
              </div>
              <div className="tap-icon sent">
                <FaFire />
              </div>
            </div>
          ))
        ) : (
          <div className="no-taps">
            <p>You haven't sent any taps yet.</p>
          </div>
        )}
      </div>
    </div>
  )
}

export default TapsPage
