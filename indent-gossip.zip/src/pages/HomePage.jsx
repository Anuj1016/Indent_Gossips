"use client"

import { useState, useEffect } from "react"
import { useAuth } from "../contexts/AuthContext"
import { firestore } from "../firebase/config"
import { collection, query, orderBy, limit, getDocs } from "firebase/firestore"
import Post from "../components/posts/Post"
import CreatePostButton from "../components/posts/CreatePostButton"
import "./HomePage.css"

function HomePage() {
  const { currentUser } = useAuth()
  const [posts, setPosts] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchPosts() {
      try {
        const postsQuery = query(collection(firestore, "posts"), orderBy("createdAt", "desc"), limit(20))

        const querySnapshot = await getDocs(postsQuery)
        const fetchedPosts = []

        querySnapshot.forEach((doc) => {
          fetchedPosts.push({
            id: doc.id,
            ...doc.data(),
          })
        })

        setPosts(fetchedPosts)
      } catch (error) {
        console.error("Error fetching posts:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchPosts()
  }, [])

  return (
    <div className="home-page">
      <div className="home-header">
        <h1>Indent Gossip</h1>
        <p>Share your thoughts anonymously</p>
      </div>

      {currentUser && <CreatePostButton />}

      <div className="posts-container">
        {loading ? (
          <div className="loading-spinner">Loading posts...</div>
        ) : posts.length > 0 ? (
          posts.map((post) => <Post key={post.id} post={post} />)
        ) : (
          <div className="no-posts">
            <p>No posts yet. Be the first to share something!</p>
          </div>
        )}
      </div>
    </div>
  )
}

export default HomePage
