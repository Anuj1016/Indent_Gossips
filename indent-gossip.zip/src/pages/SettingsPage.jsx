"use client"

import { useState } from "react"
import { useAuth } from "../contexts/AuthContext"
import { FaUser, FaLock, FaEye, FaSignOutAlt, FaQuestionCircle, FaFileAlt } from "react-icons/fa"
import "./SettingsPage.css"

function SettingsPage() {
  const { currentUser, logout } = useAuth()
  const [activeSection, setActiveSection] = useState("profile")

  const handleLogout = async () => {
    try {
      await logout()
      // Redirect will happen automatically due to protected route
    } catch (error) {
      console.error("Failed to log out", error)
    }
  }

  return (
    <div className="settings-page">
      <h1>Settings</h1>

      <div className="settings-container">
        <div className="settings-sidebar">
          <button
            className={`sidebar-item ${activeSection === "profile" ? "active" : ""}`}
            onClick={() => setActiveSection("profile")}
          >
            <FaUser /> Profile
          </button>
          <button
            className={`sidebar-item ${activeSection === "security" ? "active" : ""}`}
            onClick={() => setActiveSection("security")}
          >
            <FaLock /> Privacy & Security
          </button>
          <button
            className={`sidebar-item ${activeSection === "visibility" ? "active" : ""}`}
            onClick={() => setActiveSection("visibility")}
          >
            <FaEye /> Visibility
          </button>
          <button
            className={`sidebar-item ${activeSection === "help" ? "active" : ""}`}
            onClick={() => setActiveSection("help")}
          >
            <FaQuestionCircle /> Help Center
          </button>
          <button
            className={`sidebar-item ${activeSection === "privacy" ? "active" : ""}`}
            onClick={() => setActiveSection("privacy")}
          >
            <FaFileAlt /> Privacy Policy
          </button>
          <button className="sidebar-item logout" onClick={handleLogout}>
            <FaSignOutAlt /> Logout
          </button>
        </div>

        <div className="settings-content">
          {activeSection === "profile" && (
            <div className="settings-section">
              <h2>Profile Settings</h2>

              <div className="form-group">
                <label>Username</label>
                <input type="text" defaultValue="Anonymous User" />
              </div>

              <div className="form-group">
                <label>Bio</label>
                <textarea defaultValue="This is a sample bio. Share a little about yourself." rows={4}></textarea>
              </div>

              <div className="form-group">
                <label>Email</label>
                <input type="email" defaultValue={currentUser?.email || "user@example.com"} disabled />
                <small>Email cannot be changed</small>
              </div>

              <button className="save-button">Save Changes</button>
            </div>
          )}

          {activeSection === "security" && (
            <div className="settings-section">
              <h2>Privacy & Security</h2>

              <div className="form-group checkbox">
                <input type="checkbox" id="two-factor" defaultChecked />
                <label htmlFor="two-factor">Enable two-factor authentication</label>
              </div>

              <div className="form-group checkbox">
                <input type="checkbox" id="data-collection" />
                <label htmlFor="data-collection">Allow anonymous data collection</label>
              </div>

              <div className="form-group">
                <label>Change Password</label>
                <input type="password" placeholder="Current password" />
                <input type="password" placeholder="New password" />
                <input type="password" placeholder="Confirm new password" />
              </div>

              <button className="save-button">Update Password</button>
            </div>
          )}

          {activeSection === "visibility" && (
            <div className="settings-section">
              <h2>Visibility Settings</h2>

              <div className="form-group checkbox">
                <input type="checkbox" id="profile-visible" defaultChecked />
                <label htmlFor="profile-visible">Make profile visible to others</label>
              </div>

              <div className="form-group checkbox">
                <input type="checkbox" id="show-activity" defaultChecked />
                <label htmlFor="show-activity">Show online activity status</label>
              </div>

              <div className="form-group checkbox">
                <input type="checkbox" id="allow-taps" defaultChecked />
                <label htmlFor="allow-taps">Allow others to tap you</label>
              </div>

              <button className="save-button">Save Changes</button>
            </div>
          )}

          {activeSection === "help" && (
            <div className="settings-section">
              <h2>Help Center</h2>

              <div className="help-item">
                <h3>How do flags work?</h3>
                <p>
                  Posts are assigned flags based on community interaction:
                  <ul>
                    <li>
                      <span className="green-dot"></span> Green Flag: More than 10 likes and fewer than 5 reports
                    </li>
                    <li>
                      <span className="red-dot"></span> Red Flag: More than 10 dislikes or more than 5 reports
                    </li>
                    <li>
                      <span className="gray-dot"></span> Blank Flag: New posts or posts with minimal interaction
                    </li>
                  </ul>
                </p>
              </div>

              <div className="help-item">
                <h3>What are taps?</h3>
                <p>
                  Taps are a way to show interest in someone without sending a message. When you tap someone, they'll
                  receive a notification and can see your profile.
                </p>
              </div>

              <div className="help-item">
                <h3>How do I report inappropriate content?</h3>
                <p>
                  You can report any post by clicking the flag icon. Our moderation team will review reported content
                  and take appropriate action.
                </p>
              </div>
            </div>
          )}

          {activeSection === "privacy" && (
            <div className="settings-section">
              <h2>Privacy Policy</h2>

              <div className="privacy-content">
                <p>
                  <strong>Last Updated: May 2023</strong>
                </p>
                <p>
                  This is a sample privacy policy for the Indent Gossip platform. In a real application, this would
                  contain detailed information about how user data is collected, stored, and used.
                </p>
                <p>
                  <strong>Information We Collect</strong>
                  <br />
                  We collect information you provide directly to us when you create an account, such as your email
                  address and username.
                </p>
                <p>
                  <strong>How We Use Your Information</strong>
                  <br />
                  We use the information we collect to provide, maintain, and improve our services, and to protect the
                  security of our platform.
                </p>
                <p>
                  <strong>Data Retention</strong>
                  <br />
                  We retain your information as long as your account is active or as needed to provide you services.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default SettingsPage
