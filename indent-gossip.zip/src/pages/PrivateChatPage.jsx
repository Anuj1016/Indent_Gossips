"use client"

import { useState, useEffect, useRef } from "react"
import { useParams } from "react-router-dom"
import { useAuth } from "../contexts/AuthContext"
import { FaPaperPlane, FaImage } from "react-icons/fa"
import "./ChatPages.css"

function PrivateChatPage() {
  const { chatId } = useParams()
  const { currentUser } = useAuth()
  const [messages, setMessages] = useState([])
  const [newMessage, setNewMessage] = useState("")
  const [chatPartner, setChatPartner] = useState({
    id: "user123",
    name: "Chat Partner",
  })
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef(null)

  // Scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    // In a real app, fetch messages from Firestore and listen for new ones with Socket.io
    // For now, we'll use mock data
    setMessages([
      {
        id: 1,
        senderId: "user123",
        senderName: "Chat Partner",
        content: "Hey there! How are you?",
        timestamp: new Date(Date.now() - 3600000).toISOString(),
      },
      {
        id: 2,
        senderId: currentUser?.uid || "currentUser",
        senderName: "You",
        content: "I'm good, thanks! How about you?",
        timestamp: new Date(Date.now() - 3000000).toISOString(),
      },
      {
        id: 3,
        senderId: "user123",
        senderName: "Chat Partner",
        content: "Doing well! Just checking out this new platform.",
        timestamp: new Date(Date.now() - 2400000).toISOString(),
      },
    ])

    // Simulate typing indicator
    const typingInterval = setInterval(() => {
      setIsTyping((prev) => !prev)
    }, 5000)

    return () => clearInterval(typingInterval)
  }, [chatId, currentUser])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = (e) => {
    e.preventDefault()

    if (!newMessage.trim()) return

    // In a real app, send message to backend/Socket.io
    const newMsg = {
      id: Date.now(),
      senderId: currentUser?.uid || "currentUser",
      senderName: "You",
      content: newMessage,
      timestamp: new Date().toISOString(),
    }

    setMessages((prev) => [...prev, newMsg])
    setNewMessage("")
  }

  const formatTime = (timestamp) => {
    const date = new Date(timestamp)
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  return (
    <div className="chat-page private-chat">
      <div className="chat-header">
        <div className="chat-partner">
          <div className="partner-avatar">{chatPartner.name.charAt(0).toUpperCase()}</div>
          <div className="partner-info">
            <h3>{chatPartner.name}</h3>
            {isTyping && <span className="typing-indicator">typing...</span>}
          </div>
        </div>
      </div>

      <div className="messages-container">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`message ${message.senderId === (currentUser?.uid || "currentUser") ? "sent" : "received"}`}
          >
            <div className="message-content">{message.content}</div>
            <div className="message-time">{formatTime(message.timestamp)}</div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      <form className="message-form" onSubmit={handleSendMessage}>
        <button type="button" className="attach-button">
          <FaImage />
        </button>
        <input
          type="text"
          placeholder="Type a message..."
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
        />
        <button type="submit" className="send-button">
          <FaPaperPlane />
        </button>
      </form>
    </div>
  )
}

export default PrivateChatPage
