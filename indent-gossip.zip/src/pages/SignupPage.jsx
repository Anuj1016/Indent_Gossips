"use client"

import { useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import { useAuth } from "../contexts/AuthContext"
import "./AuthPages.css"

function SignupPage() {
  const [username, setUsername] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [otpSent, setOtpSent] = useState(false)
  const [otp, setOtp] = useState("")
  const [otpVerified, setOtpVerified] = useState(false)
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const { signup } = useAuth()
  const navigate = useNavigate()

  const validateEmail = (email) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return re.test(email)
  }

  const handleSendOTP = async (e) => {
    e.preventDefault()

    if (!username.trim()) {
      return setError("Username is required")
    }

    if (!validateEmail(email)) {
      return setError("Please enter a valid email address")
    }

    if (password.length < 6) {
      return setError("Password must be at least 6 characters")
    }

    if (password !== confirmPassword) {
      return setError("Passwords do not match")
    }

    setError("")
    setLoading(true)

    try {
      // In a real app, you would send an OTP to the user's email
      // For this demo, we'll simulate it
      setTimeout(() => {
        setOtpSent(true)
        setLoading(false)
      }, 1500)
    } catch (error) {
      setError("Failed to send OTP. Please try again.")
      setLoading(false)
    }
  }

  const handleVerifyOTP = (e) => {
    e.preventDefault()

    if (!otp.trim() || otp.length !== 6) {
      return setError("Please enter a valid 6-digit OTP")
    }

    setError("")
    setLoading(true)

    // In a real app, you would verify the OTP with your backend
    // For this demo, we'll simulate it with a fixed OTP
    setTimeout(() => {
      if (otp === "123456") {
        setOtpVerified(true)
      } else {
        setError("Invalid OTP. Please try again.")
      }
      setLoading(false)
    }, 1500)
  }

  const handleSignup = async (e) => {
    e.preventDefault()

    if (!otpVerified) {
      return setError("Please verify your email first")
    }

    setError("")
    setLoading(true)

    try {
      await signup(email, password, username)
      navigate("/verification")
    } catch (error) {
      setError("Failed to create an account: " + error.message)
      setLoading(false)
    }
  }

  return (
    <div className="auth-page signup-page">
      <div className="auth-container">
        <div className="auth-background">
          <div className="auth-overlay"></div>
        </div>

        <div className="auth-card">
          <h2>Create an Account</h2>
          <p className="auth-subtitle">Join Indent Gossip and start sharing anonymously</p>

          {error && <div className="error-message">{error}</div>}

          {!otpSent ? (
            <form onSubmit={handleSendOTP} className="auth-form">
              <div className="form-group">
                <label htmlFor="username">Username</label>
                <input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Choose a username"
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="email">Email</label>
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Your email address"
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="password">Password</label>
                <input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Create a password"
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="confirmPassword">Confirm Password</label>
                <input
                  id="confirmPassword"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Confirm your password"
                  required
                />
              </div>

              <button type="submit" className="auth-button" disabled={loading}>
                {loading ? "Sending OTP..." : "Verify Email"}
              </button>
            </form>
          ) : !otpVerified ? (
            <form onSubmit={handleVerifyOTP} className="auth-form">
              <p className="otp-message">We've sent a verification code to your email. Please enter it below.</p>

              <div className="form-group">
                <label htmlFor="otp">Verification Code</label>
                <input
                  id="otp"
                  type="text"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                  placeholder="Enter 6-digit code"
                  maxLength={6}
                  required
                />
              </div>

              <button type="submit" className="auth-button" disabled={loading}>
                {loading ? "Verifying..." : "Verify OTP"}
              </button>
            </form>
          ) : (
            <form onSubmit={handleSignup} className="auth-form">
              <p className="success-message">Email verified successfully!</p>

              <button type="submit" className="auth-button" disabled={loading}>
                {loading ? "Creating Account..." : "Sign Up"}
              </button>
            </form>
          )}

          <div className="auth-footer">
            Already have an account? <Link to="/login">Log In</Link>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SignupPage
