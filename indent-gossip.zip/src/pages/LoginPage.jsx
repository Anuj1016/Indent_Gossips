"use client"

import { useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import { useAuth } from "../contexts/AuthContext"
import "./AuthPages.css"

function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [otp, setOtp] = useState("")
  const [otpSent, setOtpSent] = useState(false)
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const { login } = useAuth()
  const navigate = useNavigate()

  const handleLogin = async (e) => {
    e.preventDefault()

    if (!email.trim() || !password.trim()) {
      return setError("Please enter both email and password")
    }

    setError("")
    setLoading(true)

    try {
      await login(email, password)
      // In a real app, you would send an OTP for 2-step verification
      // For this demo, we'll simulate it
      setOtpSent(true)
      setLoading(false)
    } catch (error) {
      setError("Failed to log in: " + error.message)
      setLoading(false)
    }
  }

  const handleVerifyOTP = async (e) => {
    e.preventDefault()

    if (!otp.trim() || otp.length !== 6) {
      return setError("Please enter a valid 6-digit OTP")
    }

    setError("")
    setLoading(true)

    // In a real app, you would verify the OTP with your backend
    // For this demo, we'll simulate it with a fixed OTP
    setTimeout(() => {
      if (otp === "123456") {
        navigate("/verification")
      } else {
        setError("Invalid OTP. Please try again.")
        setLoading(false)
      }
    }, 1500)
  }

  return (
    <div className="auth-page login-page">
      <div className="auth-container">
        <div className="auth-background">
          <div className="auth-overlay"></div>
        </div>

        <div className="auth-card">
          <h2>Welcome Back</h2>
          <p className="auth-subtitle">Log in to your Indent Gossip account</p>

          {error && <div className="error-message">{error}</div>}

          {!otpSent ? (
            <form onSubmit={handleLogin} className="auth-form">
              <div className="form-group">
                <label htmlFor="email">Email</label>
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Your email address"
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="password">Password</label>
                <input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Your password"
                  required
                />
              </div>

              <div className="forgot-password">
                <Link to="/forgot-password">Forgot password?</Link>
              </div>

              <button type="submit" className="auth-button" disabled={loading}>
                {loading ? "Logging in..." : "Log In"}
              </button>
            </form>
          ) : (
            <form onSubmit={handleVerifyOTP} className="auth-form">
              <p className="otp-message">We've sent a verification code to your email. Please enter it below.</p>

              <div className="form-group">
                <label htmlFor="otp">Verification Code</label>
                <input
                  id="otp"
                  type="text"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                  placeholder="Enter 6-digit code"
                  maxLength={6}
                  required
                />
              </div>

              <button type="submit" className="auth-button" disabled={loading}>
                {loading ? "Verifying..." : "Verify OTP"}
              </button>
            </form>
          )}

          <div className="auth-footer">
            Don't have an account? <Link to="/signup">Sign Up</Link>
          </div>
        </div>
      </div>
    </div>
  )
}

export default LoginPage
