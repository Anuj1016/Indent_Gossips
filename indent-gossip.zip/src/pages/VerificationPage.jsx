"use client"

import { useState, useEffect } from "react"
import { useNavigate } from "react-router-dom"
import { FaArrowRight } from "react-icons/fa"
import "./VerificationPage.css"

function VerificationPage() {
  const [arrowPosition, setArrowPosition] = useState({ x: 0, y: 0 })
  const [targetPosition, setTargetPosition] = useState({ x: 0, y: 0 })
  const [isDragging, setIsDragging] = useState(false)
  const [isVerified, setIsVerified] = useState(false)
  const [useFallback, setUseFallback] = useState(false)
  const navigate = useNavigate()

  useEffect(() => {
    // Set random target position
    const targetX = Math.floor(Math.random() * (window.innerWidth - 200)) + 100
    const targetY = Math.floor(Math.random() * (window.innerHeight - 300)) + 150
    setTargetPosition({ x: targetX, y: targetY })

    // Set initial arrow position
    setArrowPosition({ x: 50, y: 50 })
  }, [])

  const handleMouseDown = (e) => {
    setIsDragging(true)
  }

  const handleMouseMove = (e) => {
    if (isDragging) {
      setArrowPosition({
        x: e.clientX - 25,
        y: e.clientY - 25,
      })
    }
  }

  const handleMouseUp = () => {
    if (isDragging) {
      setIsDragging(false)

      // Check if arrow is close to target
      const distance = Math.sqrt(
        Math.pow(arrowPosition.x - targetPosition.x, 2) + Math.pow(arrowPosition.y - targetPosition.y, 2),
      )

      if (distance < 50) {
        setIsVerified(true)
        setTimeout(() => {
          navigate("/")
        }, 1500)
      } else {
        // Reset arrow position
        setArrowPosition({ x: 50, y: 50 })
      }
    }
  }

  const handleFallbackVerification = () => {
    setIsVerified(true)
    setTimeout(() => {
      navigate("/")
    }, 1500)
  }

  const toggleVerificationMethod = () => {
    setUseFallback(!useFallback)
  }

  return (
    <div
      className="verification-page"
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      <div className="verification-container">
        <h2>Human Verification</h2>
        <p>Please complete this verification to continue</p>

        {isVerified ? (
          <div className="verification-success">
            <div className="success-icon">✓</div>
            <h3>Verification Successful!</h3>
            <p>Redirecting to the homepage...</p>
          </div>
        ) : useFallback ? (
          <div className="fallback-verification">
            <label className="checkbox-container">
              <input type="checkbox" onChange={handleFallbackVerification} />
              <span className="checkmark"></span>
              I'm not a robot
            </label>
          </div>
        ) : (
          <div className="arrow-puzzle">
            <div
              className="arrow"
              style={{
                left: `${arrowPosition.x}px`,
                top: `${arrowPosition.y}px`,
                cursor: isDragging ? "grabbing" : "grab",
              }}
              onMouseDown={handleMouseDown}
            >
              <FaArrowRight />
            </div>

            <div
              className="target"
              style={{
                left: `${targetPosition.x}px`,
                top: `${targetPosition.y}px`,
              }}
            ></div>

            <div className="instructions">Drag the arrow toward the circle</div>
          </div>
        )}

        <button className="toggle-method" onClick={toggleVerificationMethod}>
          {useFallback ? "Try Arrow Puzzle" : "Use Checkbox Instead"}
        </button>
      </div>
    </div>
  )
}

export default VerificationPage
