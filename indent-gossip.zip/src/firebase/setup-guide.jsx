/**
 * FIREBASE SETUP GUIDE
 *
 * 1. Go to https://console.firebase.google.com/
 * 2. Click "Add project" and follow the steps to create a new Firebase project
 * 3. Once your project is created, click on the web icon (</>) to add a web app
 * 4. Register your app with a nickname (e.g., "indent-gossip-web")
 * 5. Copy the Firebase configuration object
 * 6. Create a .env file in your project root with the following variables:
 *    VITE_FIREBASE_API_KEY=your-api-key
 *    VITE_FIREBASE_AUTH_DOMAIN=your-project-id.firebaseapp.com
 *    VITE_FIREBASE_PROJECT_ID=your-project-id
 *    VITE_FIREBASE_STORAGE_BUCKET=your-project-id.appspot.com
 *    VITE_FIREBASE_MESSAGING_SENDER_ID=your-messaging-sender-id
 *    VITE_FIREBASE_APP_ID=your-app-id
 *
 * 7. Enable Authentication:
 *    - Go to Authentication > Sign-in method
 *    - Enable Email/Password provider
 *
 * 8. Create Firestore Database:
 *    - Go to Firestore Database > Create database
 *    - Start in production mode
 *    - Choose a location close to your users
 *
 * 9. Set up Storage:
 *    - Go to Storage > Get started
 *    - Start in production mode
 *    - Choose the same location as your Firestore
 *
 * 10. Generate a service account key for backend:
 *     - Go to Project settings > Service accounts
 *     - Click "Generate new private key"
 *     - Save the JSON file as "serviceAccountKey.json" in your backend directory
 */
