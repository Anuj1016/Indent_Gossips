"use client"

import { Link, useLocation } from "react-router-dom"
import { FaPlus, FaComments, FaUsers, FaFire } from "react-icons/fa"
import { useAuth } from "../../contexts/AuthContext"
import "./Footer.css"

function Footer() {
  const { currentUser } = useAuth()
  const location = useLocation()

  const isActive = (path) => {
    return location.pathname === path
  }

  return (
    <footer className="footer">
      <div className="container footer-container">
        {currentUser ? (
          <div className="footer-nav">
            <Link to="/private-chat" className={`footer-nav-item ${isActive("/private-chat") ? "active" : ""}`}>
              <FaComments />
              <span>Private</span>
            </Link>
            <Link to="/public-chat" className={`footer-nav-item ${isActive("/public-chat") ? "active" : ""}`}>
              <FaUsers />
              <span>Public</span>
            </Link>
            <Link to="/create-post" className="footer-nav-item add-button">
              <div className="add-icon-wrapper">
                <FaPlus />
              </div>
            </Link>
            <Link to="/taps" className={`footer-nav-item ${isActive("/taps") ? "active" : ""}`}>
              <FaFire />
              <span>Taps</span>
            </Link>
            <Link
              to={`/profile/${currentUser.uid}`}
              className={`footer-nav-item ${isActive(`/profile/${currentUser.uid}`) ? "active" : ""}`}
            >
              <div className="profile-mini">
                {currentUser.photoURL ? (
                  <img src={currentUser.photoURL || "/placeholder.svg"} alt="Profile" />
                ) : (
                  <div className="profile-placeholder"></div>
                )}
              </div>
              <span>Profile</span>
            </Link>
          </div>
        ) : (
          <div className="footer-info">
            <p>© 2023 Indent Gossip. All rights reserved.</p>
            <div className="footer-links">
              <Link to="/about">About</Link>
              <Link to="/privacy">Privacy Policy</Link>
              <Link to="/terms">Terms of Service</Link>
              <Link to="/help">Help Center</Link>
            </div>
          </div>
        )}
      </div>
    </footer>
  )
}

export default Footer
