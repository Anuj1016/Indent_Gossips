"use client"

import { useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import { useAuth } from "../../contexts/AuthContext"
import { useTheme } from "../../contexts/ThemeContext"
import { FaSearch, FaUser, FaSignInAlt, FaMoon, FaSun } from "react-icons/fa"
import "./Header.css"

function Header() {
  const { currentUser, userProfile } = useAuth()
  const { darkMode, toggleTheme } = useTheme()
  const [searchQuery, setSearchQuery] = useState("")
  const [showProfileMenu, setShowProfileMenu] = useState(false)
  const navigate = useNavigate()

  const handleSearch = (e) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`)
    }
  }

  const toggleProfileMenu = () => {
    setShowProfileMenu(!showProfileMenu)
  }

  return (
    <header className="header">
      <div className="container header-container">
        <div className="logo">
          <Link to="/">
            <h1>Indent Gossip</h1>
          </Link>
        </div>

        <form className="search-bar" onSubmit={handleSearch}>
          <input
            type="text"
            placeholder="Search users, tags, interests..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <button type="submit" className="search-button">
            <FaSearch />
          </button>
        </form>

        <div className="header-actions">
          <button className="theme-toggle" onClick={toggleTheme}>
            {darkMode ? <FaSun /> : <FaMoon />}
          </button>

          {currentUser ? (
            <div className="profile-section">
              <div className="profile-icon" onClick={toggleProfileMenu}>
                {userProfile?.profilePicture ? (
                  <img src={userProfile.profilePicture || "/placeholder.svg"} alt="Profile" className="profile-image" />
                ) : (
                  <FaUser />
                )}
              </div>

              {showProfileMenu && (
                <div className="profile-menu">
                  <Link to={`/profile/${currentUser.uid}`}>Profile</Link>
                  <Link to="/settings">Settings</Link>
                  <Link to="/taps">Taps</Link>
                  <div className="menu-divider"></div>
                  <Link to="/settings/privacy">Privacy & Security</Link>
                  <Link to="/settings/visibility">Visibility</Link>
                  <Link to="/logout">Logout</Link>
                </div>
              )}
            </div>
          ) : (
            <div className="auth-links">
              <Link to="/login" className="login-link">
                <FaSignInAlt /> Login
              </Link>
              <Link to="/signup" className="signup-button">
                Sign Up
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}

export default Header
