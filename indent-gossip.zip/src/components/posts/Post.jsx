"use client"

import { useState } from "react"
import { Link } from "react-router-dom"
import { FaHeart, FaRegHeart, FaFlag, FaComment, FaShare, FaEllipsisH } from "react-icons/fa"
import { useAuth } from "../../contexts/AuthContext"
import { firestore } from "../../firebase/config"
import { doc, updateDoc, arrayUnion, arrayRemove, increment } from "firebase/firestore"
import "./Post.css"

function Post({ post }) {
  const { currentUser } = useAuth()
  const [showComments, setShowComments] = useState(false)
  const [comment, setComment] = useState("")
  const [showOptions, setShowOptions] = useState(false)

  const {
    id,
    content,
    createdAt,
    authorId,
    authorName,
    likes = [],
    dislikes = [],
    reports = [],
    comments = [],
    flagStatus = "blank",
  } = post

  const isLiked = currentUser && likes.includes(currentUser.uid)
  const isDisliked = currentUser && dislikes.includes(currentUser.uid)
  const isReported = currentUser && reports.includes(currentUser.uid)

  const handleLike = async () => {
    if (!currentUser) return

    const postRef = doc(firestore, "posts", id)

    try {
      if (isLiked) {
        await updateDoc(postRef, {
          likes: arrayRemove(currentUser.uid),
        })
      } else {
        // Remove from dislikes if it was disliked
        if (isDisliked) {
          await updateDoc(postRef, {
            dislikes: arrayRemove(currentUser.uid),
          })
        }

        await updateDoc(postRef, {
          likes: arrayUnion(currentUser.uid),
        })
      }

      // Update flag status based on likes and reports
      await updateFlagStatus(
        postRef,
        likes.length + (isLiked ? -1 : 1),
        dislikes.length - (isDisliked ? 1 : 0),
        reports.length,
      )
    } catch (error) {
      console.error("Error updating like:", error)
    }
  }

  const handleDislike = async () => {
    if (!currentUser) return

    const postRef = doc(firestore, "posts", id)

    try {
      if (isDisliked) {
        await updateDoc(postRef, {
          dislikes: arrayRemove(currentUser.uid),
        })
      } else {
        // Remove from likes if it was liked
        if (isLiked) {
          await updateDoc(postRef, {
            likes: arrayRemove(currentUser.uid),
          })
        }

        await updateDoc(postRef, {
          dislikes: arrayUnion(currentUser.uid),
        })
      }

      // Update flag status based on likes and reports
      await updateFlagStatus(
        postRef,
        likes.length - (isLiked ? 1 : 0),
        dislikes.length + (isDisliked ? -1 : 1),
        reports.length,
      )
    } catch (error) {
      console.error("Error updating dislike:", error)
    }
  }

  const handleReport = async () => {
    if (!currentUser) return

    const postRef = doc(firestore, "posts", id)

    try {
      if (isReported) {
        await updateDoc(postRef, {
          reports: arrayRemove(currentUser.uid),
        })
      } else {
        await updateDoc(postRef, {
          reports: arrayUnion(currentUser.uid),
        })
      }

      // Update flag status based on likes and reports
      await updateFlagStatus(postRef, likes.length, dislikes.length, reports.length + (isReported ? -1 : 1))

      // Update user's red flag count if needed
      if (reports.length + (isReported ? -1 : 1) >= 5) {
        const userRef = doc(firestore, "users", authorId)
        await updateDoc(userRef, {
          redFlaggedPosts: increment(1),
        })
      }
    } catch (error) {
      console.error("Error updating report:", error)
    }
  }

  const updateFlagStatus = async (postRef, likesCount, dislikesCount, reportsCount) => {
    let newStatus = "blank"

    if (likesCount > 10 && reportsCount < 5) {
      newStatus = "green"
    } else if (dislikesCount > 10 || reportsCount > 5) {
      newStatus = "red"
    }

    if (newStatus !== flagStatus) {
      await updateDoc(postRef, {
        flagStatus: newStatus,
      })
    }
  }

  const handleAddComment = async (e) => {
    e.preventDefault()

    if (!currentUser || !comment.trim()) return

    const postRef = doc(firestore, "posts", id)

    try {
      const newComment = {
        id: Date.now().toString(),
        content: comment,
        authorId: currentUser.uid,
        authorName: currentUser.displayName || "Anonymous",
        createdAt: new Date().toISOString(),
      }

      await updateDoc(postRef, {
        comments: arrayUnion(newComment),
      })

      setComment("")
    } catch (error) {
      console.error("Error adding comment:", error)
    }
  }

  const toggleComments = () => {
    setShowComments(!showComments)
  }

  const toggleOptions = () => {
    setShowOptions(!showOptions)
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <div className="post">
      <div className="post-header">
        <div className="post-author">
          <Link to={`/profile/${authorId}`} className="author-name">
            {authorName || "Anonymous"}
          </Link>
          <span className="post-time">{formatDate(createdAt)}</span>
        </div>

        <div className="post-flag">
          <span className={`flag-icon ${flagStatus}-flag`}>
            <FaFlag />
          </span>
        </div>

        <div className="post-options">
          <button className="options-button" onClick={toggleOptions}>
            <FaEllipsisH />
          </button>

          {showOptions && (
            <div className="options-menu">
              <button>Copy Link</button>
              <button>Mute User</button>
              <button className="danger">Block User</button>
            </div>
          )}
        </div>
      </div>

      <div className="post-content">{content}</div>

      <div className="post-actions">
        <button className={`action-button ${isLiked ? "active" : ""}`} onClick={handleLike}>
          {isLiked ? <FaHeart /> : <FaRegHeart />}
          <span>{likes.length}</span>
        </button>

        <button className={`action-button ${isDisliked ? "active danger" : ""}`} onClick={handleDislike}>
          <FaRegHeart className="dislike-icon" />
          <span>{dislikes.length}</span>
        </button>

        <button className="action-button" onClick={toggleComments}>
          <FaComment />
          <span>{comments.length}</span>
        </button>

        <button className="action-button">
          <FaShare />
        </button>

        <button className={`action-button report-button ${isReported ? "active danger" : ""}`} onClick={handleReport}>
          <FaFlag />
          <span>{isReported ? "Reported" : "Report"}</span>
        </button>
      </div>

      {showComments && (
        <div className="post-comments">
          <h4>Comments ({comments.length})</h4>

          <form onSubmit={handleAddComment} className="comment-form">
            <input
              type="text"
              placeholder="Add a comment..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              required
            />
            <button type="submit">Post</button>
          </form>

          <div className="comments-list">
            {comments.length > 0 ? (
              comments.map((comment) => (
                <div key={comment.id} className="comment">
                  <div className="comment-header">
                    <Link to={`/profile/${comment.authorId}`} className="comment-author">
                      {comment.authorName || "Anonymous"}
                    </Link>
                    <span className="comment-time">{formatDate(comment.createdAt)}</span>
                  </div>
                  <div className="comment-content">{comment.content}</div>
                </div>
              ))
            ) : (
              <p className="no-comments">No comments yet. Be the first to comment!</p>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

export default Post
