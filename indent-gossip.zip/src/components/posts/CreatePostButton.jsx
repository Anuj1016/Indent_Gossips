"use client"

import { useState } from "react"
import { FaPlus, FaTimes } from "react-icons/fa"
import { useAuth } from "../../contexts/AuthContext"
import { firestore } from "../../firebase/config"
import { collection, addDoc } from "firebase/firestore"
import "./CreatePostButton.css"

function CreatePostButton() {
  const [showModal, setShowModal] = useState(false)
  const [content, setContent] = useState("")
  const [loading, setLoading] = useState(false)
  const { currentUser } = useAuth()

  const openModal = () => {
    setShowModal(true)
  }

  const closeModal = () => {
    setShowModal(false)
    setContent("")
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!currentUser || !content.trim()) return

    setLoading(true)

    try {
      await addDoc(collection(firestore, "posts"), {
        content: content.trim(),
        authorId: currentUser.uid,
        authorName: currentUser.displayName || "Anonymous",
        createdAt: new Date().toISOString(),
        likes: [],
        dislikes: [],
        reports: [],
        comments: [],
        flagStatus: "blank",
      })

      closeModal()
    } catch (error) {
      console.error("Error creating post:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <button className="create-post-button" onClick={openModal}>
        <FaPlus />
        <span>Create Post</span>
      </button>

      {showModal && (
        <div className="modal-overlay">
          <div className="create-post-modal">
            <div className="modal-header">
              <h3>Create Post</h3>
              <button className="close-button" onClick={closeModal}>
                <FaTimes />
              </button>
            </div>

            <form onSubmit={handleSubmit}>
              <textarea
                placeholder="What's on your mind?"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                maxLength={500}
                required
              ></textarea>

              <div className="character-count">{content.length}/500</div>

              <div className="modal-footer">
                <button type="button" className="cancel-button" onClick={closeModal}>
                  Cancel
                </button>
                <button type="submit" className="post-button" disabled={loading || !content.trim()}>
                  {loading ? "Posting..." : "Post"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  )
}

export default CreatePostButton
