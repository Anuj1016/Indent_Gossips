import { io } from "socket.io-client"

// API base URL
const API_BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api"

// Socket.io connection
export const socket = io(import.meta.env.VITE_SOCKET_URL || "http://localhost:5000", {
  autoConnect: false,
})

// API functions
export const api = {
  // User endpoints
  getUser: async (userId) => {
    const response = await fetch(`${API_BASE_URL}/users/${userId}`)
    if (!response.ok) throw new Error("Failed to fetch user")
    return response.json()
  },

  // Posts endpoints
  getPosts: async () => {
    const response = await fetch(`${API_BASE_URL}/posts`)
    if (!response.ok) throw new Error("Failed to fetch posts")
    return response.json()
  },

  createPost: async (postData) => {
    const response = await fetch(`${API_BASE_URL}/posts`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(postData),
    })
    if (!response.ok) throw new Error("Failed to create post")
    return response.json()
  },

  // Chat functions
  connectToChat: (userId) => {
    if (!socket.connected) {
      socket.auth = { userId }
      socket.connect()
    }
    return socket
  },

  disconnectFromChat: () => {
    if (socket.connected) {
      socket.disconnect()
    }
  },

  joinPrivateChat: (chatId) => {
    socket.emit("join_private_chat", chatId)
  },

  joinPublicChat: (roomId) => {
    socket.emit("join_public_chat", roomId)
  },

  sendPrivateMessage: (messageData) => {
    socket.emit("private_message", messageData)
  },

  sendPublicMessage: (messageData) => {
    socket.emit("public_message", messageData)
  },

  setTypingStatus: (data) => {
    socket.emit("typing", data)
  },
}

export default api
