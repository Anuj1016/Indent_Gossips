import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import { AuthProvider } from "./contexts/AuthContext"
import { ThemeProvider } from "./contexts/ThemeContext"
import ProtectedRoute from "./components/auth/ProtectedRoute"
import Header from "./components/layout/Header"
import Footer from "./components/layout/Footer"
import HomePage from "./pages/HomePage"
import SignupPage from "./pages/SignupPage"
import LoginPage from "./pages/LoginPage"
import VerificationPage from "./pages/VerificationPage"
import ProfilePage from "./pages/ProfilePage"
import PrivateChatPage from "./pages/PrivateChatPage"
import PublicChatPage from "./pages/PublicChatPage"
import TapsPage from "./pages/TapsPage"
import SettingsPage from "./pages/SettingsPage"
import "./App.css"

function App() {
  return (
    <Router>
      <AuthProvider>
        <ThemeProvider>
          <div className="app">
            <Header />
            <main className="main-content">
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/signup" element={<SignupPage />} />
                <Route path="/login" element={<LoginPage />} />
                <Route path="/verification" element={<VerificationPage />} />
                <Route
                  path="/profile/:userId"
                  element={
                    <ProtectedRoute>
                      <ProfilePage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/private-chat/:chatId"
                  element={
                    <ProtectedRoute>
                      <PrivateChatPage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/public-chat"
                  element={
                    <ProtectedRoute>
                      <PublicChatPage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/taps"
                  element={
                    <ProtectedRoute>
                      <TapsPage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/settings"
                  element={
                    <ProtectedRoute>
                      <SettingsPage />
                    </ProtectedRoute>
                  }
                />
              </Routes>
            </main>
            <Footer />
          </div>
        </ThemeProvider>
      </AuthProvider>
    </Router>
  )
}

export default App
